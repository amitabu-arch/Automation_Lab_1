/*
 * Smart Polling Station - Arduino Uno
 * ------------------------------------
 * Components:
 *   LCD 16x2 I2C   -> SDA=A4, SCL=A5, VCC=+5V, GND
 *   Red LED        -> pin 8 (via 1k resistor)
 *   Green LED      -> pin 7 (via 1k resistor)
 *   Push button    -> pin 2 + GND (INPUT_PULLUP)
 *   IR receiver    -> S=pin 11, +=5V, -=GND
 *   Servo          -> signal=pin 9, red=5V, brown=GND
 *   HC-SR04        -> Trig=pin 6, Echo=pin 5, VCC=5V, GND
 *   Light sensor   -> LM393 LDR module: AO=A0, VCC=5V, GND
 *   Microphone     -> digital sound module (3 pins): OUT=A1, VCC=5V, GND
 *
 * How it works:
 *   1. Button opens / closes the polling station.
 *   2. When open, the ultrasonic sensor detects a voter (< 30 cm).
 *   3. The voter presses 4 / 5 / 7 on the IR remote (party A / B / C).
 *   4. Servo opens the ballot box, green LED, vote is counted.
 *   5. Remote 0 shows the results on the LCD and Serial Monitor.
 *   6. Microphone: noise in the station -> "Quiet please!" + red LED blink.
 *   7. Light sensor: too dark -> "LOW LIGHT!" warning on the LCD.
 *   8. After voting, the voter must step away (1 s out of range) before
 *      the next vote is accepted -> no double voting.
 *
 * Libraries: LiquidCrystal I2C (Frank de Brabander), IRremote (ArminJo)
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <IRremote.hpp>
#include <Servo.h>

// ---------- Settings ----------
#define SIMULATION false        // true = positional servo (Tinkercad), false = 360 servo (kit)

const byte LCD_ADDRESS = 0x27;  // change to 0x3F if the screen stays empty

// ---------- Pins ----------
const int BUTTON_PIN = 2;
const int ECHO_PIN   = 5;
const int TRIG_PIN   = 6;
const int GREEN_LED  = 7;
const int RED_LED    = 8;
const int SERVO_PIN  = 9;
const int IR_PIN     = 11;
const int LDR_PIN    = A0;
const int MIC_PIN    = A1;

// ---------- IR remote codes ----------
// Kit remote codes (measured). Voting keys: 4 = party A, 5 = party B, 7 = party C
const uint8_t IR_KEY_RESULTS = 0x16;   // key 0
const uint8_t IR_KEY_A = 0x08;         // key 4
const uint8_t IR_KEY_B = 0x1C;         // key 5
const uint8_t IR_KEY_C = 0x42;         // key 7
const char PARTY_NAMES[] = {'A', 'B', 'C'};

// ---------- Constants ----------
const int  VOTER_DISTANCE_CM = 30;    // closer than this = voter present
const int  NUM_PARTIES       = 3;
const int  SERVO_STOP        = 90;    // 360 servo: stop value (tune 88-93)
const int  SERVO_TURN_MS     = 400;   // 360 servo: how long to turn
const unsigned long SENSOR_INTERVAL_MS = 200;
const unsigned long VOTER_GONE_MS = 1000;   // voter counts as gone after 1 s out of range

// Light sensor (LM393 module: MORE light = LOWER value)
const int  LDR_DARK_THRESHOLD = 700;  // above this = too dark (tune from your measurements)
const unsigned long LDR_INTERVAL_MS = 1000;

// Microphone (digital module: OUT pulses HIGH on noise (our module); change to LOW if reversed)
const int  SOUND_DETECTED   = HIGH;
const unsigned long NOISE_COOLDOWN_MS = 2000;   // ignore noise right after a warning

// ---------- System states ----------
enum State { CLOSED, WAITING, VOTER_PRESENT };

State state = CLOSED;
int votes[NUM_PARTIES] = {0, 0, 0};
int totalVotes = 0;

bool lastButtonPressed = false;
unsigned long lastSensorRead = 0;
unsigned long lastVoterNearTime = 0;
bool waitForVoterToLeave = false;           // blocks a second vote by the same voter

bool lowLight = false;
unsigned long lastLdrRead = 0;

int noiseCount = 0;
unsigned long lastNoiseTime = 0;

LiquidCrystal_I2C lcd(LCD_ADDRESS, 16, 2);
Servo ballotServo;

// =====================================================
void setup() {
  Serial.begin(9600);

  pinMode(BUTTON_PIN, INPUT_PULLUP);
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(MIC_PIN, INPUT);

  lcd.init();
  lcd.backlight();

  IrReceiver.begin(IR_PIN, ENABLE_LED_FEEDBACK);

  ballotServo.attach(SERVO_PIN);
  closeBox();

  Serial.println("=== Smart Polling Station started ===");
  setState(CLOSED);
}

// =====================================================
void loop() {
  handleButton();
  handleSensor();
  handleRemote();
  handleLight();
  handleNoise();
}

// ---------- Button: open / close the station ----------
void handleButton() {
  bool pressed = (digitalRead(BUTTON_PIN) == LOW);

  if (pressed && !lastButtonPressed) {
    if (state == CLOSED) {
      Serial.println("Button: station OPENED");
      setState(WAITING);
    } else {
      Serial.println("Button: station CLOSED");
      setState(CLOSED);
      printResults();
    }
    delay(200);   // debounce
  }
  lastButtonPressed = pressed;
}

// ---------- Ultrasonic: detect a voter ----------
void handleSensor() {
  if (state == CLOSED) return;
  if (millis() - lastSensorRead < SENSOR_INTERVAL_MS) return;
  lastSensorRead = millis();

  int distance = readDistanceCm();
  bool voterNear = (distance > 0 && distance < VOTER_DISTANCE_CM);
  if (voterNear) lastVoterNearTime = millis();
  bool voterGone = (millis() - lastVoterNearTime > VOTER_GONE_MS);  // ignores single bad readings

  // After a vote: wait until the voter walks away before accepting a new one
  if (waitForVoterToLeave) {
    if (voterGone) {
      waitForVoterToLeave = false;
      Serial.println("Previous voter left - ready for next voter");
      if (state == WAITING) setState(WAITING);   // refresh screen
    }
    return;
  }

  if (state == WAITING && voterNear) {
    Serial.print("Voter detected at ");
    Serial.print(distance);
    Serial.println(" cm");
    setState(VOTER_PRESENT);
  } else if (state == VOTER_PRESENT && voterGone) {
    Serial.println("Voter left without voting");
    setState(WAITING);
  }
}

// ---------- IR remote: vote / show results ----------
void handleRemote() {
  if (!IrReceiver.decode()) return;

  bool isRepeat = IrReceiver.decodedIRData.flags & IRDATA_FLAGS_IS_REPEAT;
  bool isNoise  = (IrReceiver.decodedIRData.protocol != NEC);   // our remote uses NEC
  uint8_t code = IrReceiver.decodedIRData.command;
  IrReceiver.resume();

  if (isRepeat || isNoise) return;   // ignore held keys and IR noise (lamps, sunlight, servo)

  Serial.print("IR code received: 0x");
  Serial.println(code, HEX);

  if (code == IR_KEY_RESULTS) {
    showResultsOnLcd();
    printResults();
    return;
  }

  int party = 0;
  if (code == IR_KEY_A) party = 1;
  else if (code == IR_KEY_B) party = 2;
  else if (code == IR_KEY_C) party = 3;

  if (party == 0) {         // unknown key: show its code
    lcd.clear();
    lcd.print("Unknown key:");
    lcd.setCursor(0, 1);
    lcd.print("0x");
    lcd.print(code, HEX);
    delay(1500);
    setState(state);
    return;
  }

  if (state == VOTER_PRESENT) {
    castVote(party);
  } else if (waitForVoterToLeave && state == WAITING) {
    Serial.println("Vote rejected: this voter already voted");
    lcd.clear();
    lcd.print("Already voted!");
    delay(1000);
    setState(state);   // redraw screen
  } else {
    Serial.println("Vote rejected: no voter at the station");
    lcd.clear();
    lcd.print(state == CLOSED ? "Station closed" : "Step closer");
    delay(1000);
    setState(state);   // redraw screen
  }
}

// ---------- Vote sequence ----------
void castVote(int party) {
  votes[party - 1]++;
  totalVotes++;

  Serial.print("Vote cast for party ");
  Serial.print(PARTY_NAMES[party - 1]);
  Serial.print(" | total votes: ");
  Serial.println(totalVotes);

  lcd.clear();
  lcd.print("Vote: party ");
  lcd.print(PARTY_NAMES[party - 1]);
  lcd.setCursor(0, 1);
  lcd.print("Thank you!");

  digitalWrite(RED_LED, LOW);
  digitalWrite(GREEN_LED, HIGH);

  openBox();
  delay(1500);
  closeBox();
  lastNoiseTime = millis();   // servo sound should not count as noise

  waitForVoterToLeave = true;  // same voter cannot vote twice
  lastVoterNearTime = millis();
  Serial.println("Waiting for voter to step away");

  setState(WAITING);
}

// ---------- State changes (LEDs + LCD + Serial) ----------
void setState(State newState) {
  state = newState;
  lcd.clear();

  switch (state) {
    case CLOSED:
      digitalWrite(RED_LED, HIGH);
      digitalWrite(GREEN_LED, LOW);
      lcd.print("Station CLOSED");
      lcd.setCursor(0, 1);
      lcd.print("Press button");
      Serial.println("State: CLOSED");
      break;

    case WAITING:
      digitalWrite(RED_LED, LOW);
      digitalWrite(GREEN_LED, HIGH);
      lcd.print("Station OPEN");
      lcd.setCursor(0, 1);
      if (waitForVoterToLeave) {
        lcd.print("Step away please");
      } else if (lowLight) {
        lcd.print("LOW LIGHT!");
      } else {
        lcd.print("Votes: ");
        lcd.print(totalVotes);
      }
      Serial.println("State: WAITING for voter");
      break;

    case VOTER_PRESENT:
      digitalWrite(RED_LED, HIGH);
      digitalWrite(GREEN_LED, HIGH);
      lcd.print("Welcome!");
      lcd.setCursor(0, 1);
      lcd.print("4=A 5=B 7=C");
      Serial.println("State: VOTER PRESENT");
      break;
  }
}

// ---------- Results ----------
void showResultsOnLcd() {
  lcd.clear();
  lcd.print("A:");
  lcd.print(votes[0]);
  lcd.print(" B:");
  lcd.print(votes[1]);
  lcd.print(" C:");
  lcd.print(votes[2]);
  lcd.setCursor(0, 1);
  lcd.print("Total: ");
  lcd.print(totalVotes);
  delay(3000);
  setState(state);
}

void printResults() {
  Serial.println("----- RESULTS -----");
  for (int i = 0; i < NUM_PARTIES; i++) {
    Serial.print("Party ");
    Serial.print(PARTY_NAMES[i]);
    Serial.print(": ");
    Serial.println(votes[i]);
  }
  Serial.print("Total: ");
  Serial.println(totalVotes);
  Serial.print("Noise warnings: ");
  Serial.println(noiseCount);
  Serial.println("-------------------");
}

// ---------- Light sensor: warn when the station is too dark ----------
void handleLight() {
  if (millis() - lastLdrRead < LDR_INTERVAL_MS) return;
  lastLdrRead = millis();

  int lightValue = analogRead(LDR_PIN);
  bool isDark = SIMULATION ? (lightValue < 1023 - LDR_DARK_THRESHOLD)  // Tinkercad divider: more light = higher
                           : (lightValue > LDR_DARK_THRESHOLD);         // LM393 module: more light = lower

  if (isDark != lowLight) {          // print only on change
    lowLight = isDark;
    Serial.print(lowLight ? "Light: LOW LIGHT warning (value " : "Light: OK (value ");
    Serial.print(lightValue);
    Serial.println(")");
    if (state == WAITING) setState(WAITING);   // refresh screen
  }
}

// ---------- Microphone: ask for quiet ----------
void handleNoise() {
  if (SIMULATION) return;            // no microphone in Tinkercad
  if (state == CLOSED) return;
  if (millis() - lastNoiseTime < NOISE_COOLDOWN_MS) return;
  if (digitalRead(MIC_PIN) != SOUND_DETECTED) return;

  noiseCount++;
  lastNoiseTime = millis();

  Serial.print("Noise detected #");
  Serial.println(noiseCount);

  lcd.clear();
  lcd.print("Quiet please!");
  lcd.setCursor(0, 1);
  lcd.print("Noise #");
  lcd.print(noiseCount);

  for (int i = 0; i < 3; i++) {      // blink red LED
    digitalWrite(RED_LED, HIGH);
    delay(200);
    digitalWrite(RED_LED, LOW);
    delay(200);
  }
  lastNoiseTime = millis();
  setState(state);                   // back to the previous screen and LEDs
}

// ---------- Servo ----------
void openBox() {
  Serial.println("Servo: opening ballot box");
  if (SIMULATION) {
    ballotServo.write(90);
  } else {
    ballotServo.write(0);
    delay(SERVO_TURN_MS);
    ballotServo.write(SERVO_STOP);
  }
}

void closeBox() {
  Serial.println("Servo: closing ballot box");
  if (SIMULATION) {
    ballotServo.write(0);
  } else {
    ballotServo.write(180);
    delay(SERVO_TURN_MS);
    ballotServo.write(SERVO_STOP);
  }
}

// ---------- Ultrasonic distance ----------
int readDistanceCm() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH, 30000);   // timeout ~5 m
  return duration * 0.034 / 2;                       // speed of sound, round trip
}
